package com.example.handler;

import androidx.appcompat.app.AppCompatActivity; // Use AppCompatActivity for modern features
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity { // Changed to AppCompatActivity
    ProgressBar myBar;
    TextView lblTopCaption;
    EditText txtBox1;
    Button btnDoSomething;
    int accum = 0;
    long startingMills = System.currentTimeMillis();
    // Updated PATIENCE string to match the new XML caption
    String PATIENCE = "Collecting important data. Please wait...\nTotal seconds so far: ";


    Handler myHandler = new Handler();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lblTopCaption = findViewById(R.id.lblTopCaption); // Use findViewById directly
        myBar = findViewById(R.id.myBar); // Use findViewById directly
        myBar.setMax(100);
        txtBox1 = findViewById(R.id.txtBox1); // Use findViewById directly
        txtBox1.setHint("Enter some data here (UI is responsive)"); // Update hint here as well
        btnDoSomething = findViewById(R.id.btnDoSomething); // Use findViewById directly

        btnDoSomething.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Editable txt = txtBox1.getText();
                Toast.makeText(getBaseContext(), "You entered: " + txt, Toast.LENGTH_LONG).show(); // Changed Toast message
            } //onClick
        }); //setOnClickListener
    } //onCreate

    @Override
    protected void onStart() {
        super.onStart();
        // create background thread where the busy work will be done
        Thread myThread1 = new Thread(backgroundTask, "backAlias1");
        myThread1.start();
        myBar.setProgress(0); // Set initial progress to 0, not increment by 0
    }

    // this is the foreground "Runnable" object responsible for GUI updates
    private Runnable foregroundTask = new Runnable() {
        @Override
        public void run() {
            try {
                int progressStep = 5;
                lblTopCaption.setText(PATIENCE + (System.currentTimeMillis() - startingMills) / 1000);
                myBar.incrementProgressBy(progressStep);
                accum += progressStep;
                if (accum >= myBar.getMax()) {
                    lblTopCaption.setText("Background work is OVER!");
                    myBar.setVisibility(View.INVISIBLE);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } //run
    }; //foregroundTask


    //this is the "Runnable" object that executes the background thread
    private Runnable backgroundTask = new Runnable() {
        @Override
        public void run() {
            //busy work goes here...
            try {
                for (int n = 0; n < 20; n++) {
                    //this simulates 1 sec. of busy activity
                    Thread.sleep(1000);
                    //now talk to the main thread
                    myHandler.post(foregroundTask);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } //run
    };//---



          //  "هذا الكود يخلي **التطبيق شغال وسريع**، حتى لو فيه **شغل ثقيل قاعد يصير في الخلفية**. يعني،
    //  المستخدم يقدر يكتب ويضغط أزرار عادي، وفي نفس الوقت فيه عملية ثانية (زي تجميع البيانات) قاعدة تشتغل من غير ما يعلق التطبيق أو يتوقف."

}