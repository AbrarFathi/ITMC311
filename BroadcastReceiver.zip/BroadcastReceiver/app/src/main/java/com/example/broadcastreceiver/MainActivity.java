package com.example.broadcastreceiver;
import androidx.appcompat.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager; // [إضافة] لاستخدام ثوابت BatteryManager لقراءة مستوى البطارية.
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast; // [إضافة] لعرض رسائل توست (اختياري).

public class MainActivity extends AppCompatActivity {

    // المتغيرات التي ستمثل عناصر الواجهة (TextView و ProgressBar)
    private TextView batteryLevelTextView;
    private ProgressBar batteryProgressBar;

    // [إضافة] تعريف كائن BroadcastReceiver. هذا المستلم سيستجيب لتغييرات البطارية.
    private BroadcastReceiver batteryInfoReceiver = new BroadcastReceiver() {
        @Override
        // هذه الدالة تُستدعى كلما تغيرت حالة البطارية (شحن، تفريغ، مستوى الشحن، إلخ).
        public void onReceive(Context context, Intent intent) {
            // [تحقق] التأكد من أن Intent يتعلق بتغيير حالة البطارية
            if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                // الحصول على مستوى البطارية من الـ Intent.
                // BatteryManager.EXTRA_LEVEL يعطي النسبة المئوية الحالية (0-100).
                int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);

                // [ربط واستخدام] تحديث ProgressBar بمستوى البطارية
                if (batteryProgressBar != null) {
                    batteryProgressBar.setProgress(level);
                }

                // [ربط واستخدام] تحديث TextView لعرض مستوى البطارية كنص
                if (batteryLevelTextView != null) {
                    batteryLevelTextView.setText("مستوى البطارية: " + level + "%");
                }

                // [إضافة اختيارية] يمكن عرض رسالة توست قصيرة للتأكيد في كل تحديث
                // Toast.makeText(context, "تم تحديث البطارية إلى: " + level + "%", Toast.LENGTH_SHORT).show();
            }
        }
    };

    /**
     * [تغيير] هذه الدالة تُستدعى عندما يتم إنشاء النشاط (Activity) لأول مرة.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // [ربط] تعيين التخطيط (Layout) الذي أنشأناه في ملف XML
        setContentView(R.layout.activity_main);

        // [ربط] البحث عن عناصر الواجهة (TextView و ProgressBar) في الـ XML
        // وربطها بالمتغيرات في الجافا باستخدام findViewById.
        batteryLevelTextView = findViewById(R.id.textfield);
        batteryProgressBar = findViewById(R.id.progressbar);

        // [إضافة] تسجيل المستلم (BroadcastReceiver)
        // هذا يخبر النظام بأننا نريد تلقي تحديثات عندما تتغير حالة البطارية.
        registerReceiver(batteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        // [إضافة] تحديث أولي للواجهة في حالة أن البطارية لم تتغير بعد بدء التطبيق مباشرة
        // (الـ IntentFilter سيقوم بتحديثها عند أول تغيير، ولكن هذا يضمن تحديثها فورًا).
        // يمكننا الحصول على القيمة الحالية يدويًا أو انتظار أول بث.
        // للحصول على القيمة الأولية، يمكن استخدام Sticky Intent أو BatteryManager.
        // لكن بما أن الـ BroadcastReceiver سيعمل فور التسجيل غالباً، فإن هذا الجزء ليس حرجاً.
    }

    /**
     * [إضافة] هذه الدالة تُستدعى عندما يتم تدمير النشاط (Activity).
     * [مهم جداً] يجب إلغاء تسجيل المستلم هنا لتجنب تسرب الذاكرة واستهلاك موارد النظام بلا داعي.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // [تنظيف] إلغاء تسجيل المستلم عند تدمير النشاط
        if (batteryInfoReceiver != null) {
            unregisterReceiver(batteryInfoReceiver);
        }
    }
}