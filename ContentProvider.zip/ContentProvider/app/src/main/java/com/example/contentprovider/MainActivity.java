package com.example.contentprovider;

import androidx.appcompat.app.AppCompatActivity;
import android.net.Uri;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // المتغيرات لحقول الإدخال لسهولة الوصول إليها
    private EditText editTextName;
    private EditText editTextGrade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // [إضافة] ربط المتغيرات بحقول الإدخال في الواجهة
        editTextName = findViewById(R.id.editText2);
        editTextGrade = findViewById(R.id.editText3);
    }

    // [تغيير] دالة إضافة اسم جديد للطلاب
    public void onClickAddName(View view) {
        // [تحسين] التحقق من أن حقول الإدخال ليست فارغة
        String name = editTextName.getText().toString().trim();
        String grade = editTextGrade.getText().toString().trim();

        if (name.isEmpty() || grade.isEmpty()) {
            Toast.makeText(getBaseContext(), "الرجاء إدخال الاسم والدرجة", Toast.LENGTH_SHORT).show();
            return; // إيقاف الدالة إذا كانت الحقول فارغة
        }

        // إنشاء كائن ContentValues لتخزين البيانات
        ContentValues values = new ContentValues();
        values.put(StudentsProvider.NAME, name);
        values.put(StudentsProvider.GRADE, grade);

        // إدراج السجل الجديد باستخدام ContentResolver
        Uri uri = getContentResolver().insert(StudentsProvider.CONTENT_URI, values);

        // [تحسين] عرض رسالة توست واضحة عند الإضافة بنجاح
        if (uri != null) {
            Toast.makeText(getBaseContext(), "تم إضافة الطالب بنجاح: " + uri.getLastPathSegment(), Toast.LENGTH_LONG).show();
            // [تحسين] مسح حقول الإدخال بعد الإضافة
            editTextName.setText("");
            editTextGrade.setText("");
        } else {
            Toast.makeText(getBaseContext(), "فشل في إضافة الطالب", Toast.LENGTH_LONG).show();
        }
    }

    // [تغيير] دالة استرداد سجلات الطلاب
    public void onClickRetrieveStudents(View view) {
        // تحديد URI لمزود المحتوى
        String URL = "content://com.example.contentprovider.StudentsProvider";
        Uri students = Uri.parse(URL);
        Cursor c = null; // تهيئة المؤشر بـ null

        try {
            // [تحسين] استرداد السجلات بترتيب تصاعدي حسب الـ ID
            c = getContentResolver().query(students, null, null, null, StudentsProvider._ID + " ASC");

            if (c != null && c.moveToFirst()) {
                StringBuilder studentInfo = new StringBuilder("الطلاب المسجلون:\n"); // [تحسين] بناء سلسلة نصية لرسالة توست أطول

                do {
                    // الحصول على فهارس الأعمدة
                    int idColIndex = c.getColumnIndex(StudentsProvider._ID);
                    int nameColIndex = c.getColumnIndex(StudentsProvider.NAME);
                    int gradeColIndex = c.getColumnIndex(StudentsProvider.GRADE);

                    // التحقق من صلاحية فهارس الأعمدة قبل الوصول إليها
                    String studentId = (idColIndex != -1) ? c.getString(idColIndex) : "N/A";
                    String studentName = (nameColIndex != -1) ? c.getString(nameColIndex) : "N/A";
                    String studentGrade = (gradeColIndex != -1) ? c.getString(gradeColIndex) : "N/A";

                    studentInfo.append("ID: ").append(studentId)
                            .append(", الاسم: ").append(studentName)
                            .append(", الدرجة: ").append(studentGrade)
                            .append("\n");

                } while (c.moveToNext());

                // [تحسين] عرض رسالة توست واحدة تحتوي على جميع الطلاب
                Toast.makeText(this, studentInfo.toString(), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "لا توجد سجلات طلاب لعرضها.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "حدث خطأ أثناء استرداد البيانات: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } finally {
            if (c != null) {
                c.close(); // [تحسين] إغلاق المؤشر لتجنب تسرب الذاكرة
            }
        }
    }
}