package com.example.thread1;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultText = findViewById(R.id.resultText); // This line will now find the TextView
    }

    // بدون استخدام Thread - يحجز الخيط الرئيسي (غير محبذ)
    public void withoutThread(View view) {
        Toast.makeText(this, "جارٍ تنفيذ المهمة بدون Thread...", Toast.LENGTH_SHORT).show();
        long endTime = System.currentTimeMillis() + 20000; // 20 ثانية
        while (System.currentTimeMillis() < endTime) {
            // لا تفعل شيئًا - فقط تشغل الخيط الرئيسي (UI Thread)
            // هذا سيجمد واجهة المستخدم بالكامل!
        }
        resultText.setText("انتهى التنفيذ بدون Thread ❌");
    }

    // باستخدام Thread - آمن وصحيح
    public void withThread(View view) {
        Toast.makeText(this, "جارٍ تنفيذ المهمة باستخدام Thread...", Toast.LENGTH_SHORT).show();
        Thread myThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(20000); // انتظر 20 ثانية في خيط الخلفية
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                // يجب تحديث واجهة المستخدم دائمًا من الخيط الرئيسي (UI Thread)
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        resultText.setText("تم التنفيذ باستخدام Thread ✅");
                    }
                });
            }
        });
        myThread.start(); // ابدأ خيط الخلفية
    }
}